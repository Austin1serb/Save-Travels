package com.austin.savetravels.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.austin.savetravels.models.Expense;
import com.austin.savetravels.repositories.ExpenseRepository;

@Service
public class ExpenseService {

    private final ExpenseRepository expenseRepository;

    public ExpenseService(ExpenseRepository expenseRepository) {
        this.expenseRepository = expenseRepository;
    }

    // returns all 
    public List<Expense> getAll() {
        return expenseRepository.findAll();
    }

    // creates 
    public Expense create(Expense e) {
        return expenseRepository.save(e);
    }

    // retrieves one by Id
    public Expense getOne(Long id) {
        Optional<Expense> optionalExpense = expenseRepository.findById(id);
        return optionalExpense.isPresent() ? optionalExpense.get() : null;
    }

    // updates/creates a expense
    public Expense update(Expense expense) {
        return expenseRepository.save(expense);
    }

    //find by description containing 
    public List<Expense> contains(String search) {
        return expenseRepository.findByDescriptionContaining(search);
    }

    //delete
    public void delete(Long id) {
        expenseRepository.deleteById(id);
    }

}
