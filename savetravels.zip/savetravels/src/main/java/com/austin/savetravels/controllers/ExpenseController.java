package com.austin.savetravels.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.austin.savetravels.models.Expense;
import com.austin.savetravels.services.ExpenseService;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/expenses")
public class ExpenseController {

    private static final String REDIRECT_TO_HOME = "redirect:/expenses";
    private final ExpenseService expenseService;

    public ExpenseController(ExpenseService expenseService) {
        this.expenseService = expenseService;
    }

    @GetMapping
    public String index(Model model) {
        model.addAttribute("allExpenses", expenseService.getAll()); // List of all expenses
        model.addAttribute("expense", new Expense());  // New expense for the form
        return "/expense/index.jsp";
    }

    @GetMapping("/new")
    public String newExpense(Model model) {
        model.addAttribute("expense", new Expense());
        return "/expense/index.jsp";
    }

    @GetMapping("/{id}")
    public String getOne(Model model, @PathVariable("id") Long id) {
        model.addAttribute("expense", expenseService.getOne(id));
        return "/expense/details.jsp";
    }

    @PostMapping
    public String create(@Valid @ModelAttribute("expense") Expense expense, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("allExpenses", expenseService.getAll());
            model.addAttribute("expense", expense);  // Add the erroneous expense object
            return "/expense/index.jsp";
        }
        expenseService.create(expense);
        return REDIRECT_TO_HOME;
    }

    @GetMapping("/{id}/edit")
    public String edit(@PathVariable("id") Long id, Model model) {
        model.addAttribute("expense", expenseService.getOne(id));
        return "/expense/edit.jsp";
    }

    @PutMapping("/{id}")
    public String update(@Valid @ModelAttribute("expense") Expense expense, BindingResult result) {
        if (result.hasErrors()) {
            return "/expense/edit.jsp";
        }
        expenseService.update(expense);
        return REDIRECT_TO_HOME;
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable("id") Long id) {
        expenseService.delete(id);
        return REDIRECT_TO_HOME;
    }
}
